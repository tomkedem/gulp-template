document.title = "Gulp example file with minification";

document.querySelector(".title").textContent= "My awesome Gulpy file";