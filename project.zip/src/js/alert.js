document.querySelector(".title").textContent = "The text from alerto.js"

const message = () =>{
    console.log("The Javascript was transplied to ES5!");
}

message();